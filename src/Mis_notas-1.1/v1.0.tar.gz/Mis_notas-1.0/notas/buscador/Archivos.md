Introducción al entorno virtual en Python

Entorno Virtual

Entorno Virtual en Python:
--------------------------
Crea entornos aislados para manejar dependencias.

Pasos básicos:
1. Crear un entorno:
    python3 -m venv mi_entorno
2. Activar:
    source mi_entorno/bin/activate
